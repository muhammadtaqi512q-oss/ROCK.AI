const express = require('express');
const path = require('path');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Database Connection
const connectDB = require('./config/db');
connectDB();

// Auth Routes
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (email && password) {
    return res.status(200).json({ success: true, token: 'mock-jwt-token-123', message: 'Logged in successfully!' });
  }
  return res.status(400).json({ success: false, error: 'Invalid credentials' });
});

app.post('/api/auth/register', (req, res) => {
  const { email, password } = req.body;
  if (email && password) {
    return res.status(201).json({ success: true, message: 'Account created successfully!' });
  }
  return res.status(400).json({ success: false, error: 'Missing required fields' });
});

// Fallback route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
