// Frontend Logic for Authentication
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('authForm');
  const alertBox = document.getElementById('alertBox');
  let isLogin = true;

  document.getElementById('toggleMode').addEventListener('click', (e) => {
    e.preventDefault();
    isLogin = !isLogin;
    document.querySelector('.auth-header h2').innerText = isLogin ? 'Welcome Back' : 'Create Account';
    document.querySelector('.auth-header p').innerText = isLogin ? 'Sign in to access your dashboard' : 'Get started with a free account';
    document.querySelector('.submit-btn').innerText = isLogin ? 'Sign In' : 'Sign Up';
    e.target.innerText = isLogin ? 'Sign up' : 'Sign in';
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    alertBox.className = 'alert';
    alertBox.innerText = 'Processing...';

    try {
      const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();
      if (response.ok) {
        alertBox.className = 'alert success';
        alertBox.innerText = data.message || 'Success! Redirecting...';
      } else {
        alertBox.className = 'alert error';
        alertBox.innerText = data.error || 'Authentication failed.';
      }
    } catch (err) {
      alertBox.className = 'alert error';
      alertBox.innerText = 'Network error. Could not reach backend.';
    }
  });
});